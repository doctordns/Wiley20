# # Chapter 2 - Section 6 - Implementing a standalond DNS Server
# Run this on SRV2 - which has the WinCompatibility moduel loaded (and is not yet a DC!)

# 1. Install the DNS Feature
Import-WinModule -Name ServerManager
Install-WindowsFeature -Name DNS -IncludeManagementTools

# 2. Set Key DNS Server Options:
# Disable recursion on this server
Set-DnsServerRecursion -Enable $false
# Configure DNS Server cache maximum size
Set-DnsServerCache  -MaxKBSize 20480  # 28 MB
# Enable EDNS
$EDNSHT = @{
  EnableProbes    = $true
  EnableReception = $true
}
Set-DnsServerEDns @EDNSHT
# Enable Global Name Zone
Set-DnsServerGlobalNameZone -Enable $true

# 3. View DNS Service and note the module
# Get DNS Server Settings
$WAHT = @{WarningAction='SilentlyContinue'}
$DNSRV = Get-DNSServer -ComputerName SRV2.Reskit.Org @WAHT
# View Recursion settinngs
$DNSRV |
  Select-Object -ExpandProperty ServerRecursion
# View Server Cache settings
$DNSRV | 
  Select-Object -ExpandProperty ServerCache
# View ENDS Settings
$DNSRV |
  Select-Object -ExpandProperty ServerEdns


