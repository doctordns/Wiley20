﻿# Recipe 8.5 - Configuring zones and resource records in DNS

# Run on SRV2

# 1. Create a new primary forward DNS zone
Import-Module -Name WindowsCompatibility
Import-WinModule DNS
$ZHT = @{
  Name              = 'Kapoho.Com'
  ReplicationScope  = 'Legacy'
  ResponsiblePerson = 'dnsadmin.reskit.org'
}
Add-DnsServerPrimaryZone @ZHT

# 2. Create a new primary reverse lookup domain (for IPv4)
$PSHT = @{
  Name              = '10.in-addr.arpa'
  ResponsiblePerson = 'DNSADMIN.Reskit.Org.'
}
Add-DnsServerPrimaryZone @PSHT


# 3. Check The DNS Zones Just Created
Get-DNSServerZone -Name 'Kapoho.com', '10.in-addr.arpa'

# 4. Add Resource Record to Kapoho.com and get results:
# Add an A record
$RRHT1 = @{
  ZoneName      =  'Kapoho.Com'
  A              =  $true
  Name           = 'Home'
  AllowUpdateAny =  $true
  IPv4Address    = '10.42.42.42'
  TimeToLive     = (30 * (24 * 60 * 60))  # 30 days in seconds
}
Add-DnsServerResourceRecord @RRHT1
# Add a Cname
$RRHT2 = @{
  ZoneName      = 'Kapoho.Com'
  Name          = 'MAIL'
  HostNameAlias = 'Home.Kapoho.Com'
  TimeToLive     = (30 * (24 * 60 * 60))  # 30 days in seconds
}
Add-DnsServerResourceRecordCName @RRHT2
# Add MX Record
$MXHT = @{
  Preference     = 10 
  Name           = '.'
  TimeToLive     = '1:00:00'
  MailExchange   = 'mail.kapoho.com'
  ZoneName       = 'kapoho.com'
}
Add-DnsServerResourceRecordMX @MXHT

# 5. Check results of RRs in Kapoho.Com zone
$Zname = 'Kapoho.com'
Get-DnsServerResourceRecord -ZoneName $Zname


# 6. Test DNS Resolution on SRV2
# Test The Cname
Resolve-DnsName -Server SRV2.Reskit.Org -Name mail.kapoho.com 
# Test The MX
Resolve-DnsName -Server SRV2.Reskit.Org -Name kapoho.com  -Type MX 

