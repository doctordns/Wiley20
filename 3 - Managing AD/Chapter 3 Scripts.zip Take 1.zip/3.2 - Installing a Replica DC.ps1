# Chapter 3 - Topic 2 - Installing Replica Domain Controller

# Run on DC2 - a workgroup computer
# DC1 is the forest root DC
# Setup DC2 using the configure environment script at github.
# if using VSCode, ensure it is setup to use PowerShell 7.


# 1. Install and load WindowsCompatability module then load 
#    the ServerManager module
Install-Module -Name WindowsCompatibility -Force
Import-Module -Name WindowsCompatibility
Import-WinModule ServerManager

# 2. Check DC1 can be resolved, and 
#    can be reached over 445 and 389 from DC2
Resolve-DnsName -Name DC1.Reskit.Org -Type A
Test-NetConnection -ComputerName DC1.Reskit.Org -Port 445
Test-NetConnection -ComputerName DC1.Reskit.Org -Port 389

# 3. Add the AD DS features on DC2
$Features = 'AD-Domain-Services', 
            'DNS','RSAT-DHCP', 
            'Web-Mgmt-Tools'
Install-WindowsFeature -Name $Features -IncludeManagementTools

# 4. Promote DC2 to be a DC in Reskit.Org
$URK = "administrator@reskit.org"
$PW  = 'Pa$$w0rd'
$PSS = ConvertTo-SecureString -String $PW -AsPlainText -Force
$Class = "System.Management.Automation.PSCredential"
$CredRK = New-Object $Class -ArgumentList $URK,$PSS
$IHT =@{
   DomainName                    = 'Reskit.org'
   SafeModeAdministratorPassword = $PSS
   SiteName                      = 'Default-First-Site-Name'
   Force                         = $true
} 
Import-WinModule -Name ADDSDeployment
Install-ADDSDomainController @IHT -Credential $CredRK | Out-Null

###  DC2 reboots at this point
### Relogon as Adminstrator@reskit.org

# 5. Check DCs in Reskit.Org
$SB = 'OU=Domain Controllers,DC=Reskit,DC=Org'
Get-ADComputer -filter * -SearchBase $SB |
  Format-Table DNSHostname, Enabled

# 6 Check Reskit.Org Forest
Get-ADDomain |
  Format-Table -Property Forest, Name, Replica*
