# 3.4 - Adding a cross Forest Trust

# Uses KapDC1 (a workgroup server with nothing else but powershell loaded)

# 1. Install and load WindowsCompatability module then load 
#    the ServerManager module on KAP DC1
Install-Module -Name WindowsCompatibility -Force
Import-Module -Name WindowsCompatibility
Import-WinModule ServerManager

# 2. Install the AD Domain Services feature and management tools
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools

# 3.Ensure network Connectivity with DC1
Test-NetConnection -ComputerName DC1

# 4. Build Installation HT to install the forest root DC for Kapoho.Com
Import-WinModule -Name ADDSDeployment
$ADINSTALLHT = @{
  String      = 'Pa$$w0rd'
  AsPlainText = $True
  Force       = $True
}
$SECUREPW = ConvertTo-SecureString @ADINSTALLHT
$ADHT = @{
  DomainName                    = 'Kapoho.Com' # Forest Root
  SafeModeAdministratorPassword = $SECUREPW
  InstallDNS                    = $True
  DomainMode                    = 'WinThreshold' # latest
  ForestMode                    = 'WinThreshold' # Latest
  Force                         = $True
}
Install-ADDSForest @ADHT | Out=Null

# 5. After Reboot - Validate Kapoho.com Forest
Get-ADForest