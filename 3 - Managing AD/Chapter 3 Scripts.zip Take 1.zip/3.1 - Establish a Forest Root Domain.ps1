﻿# Chapter 3 - Topic 1 - Installing Active Directory with DNS

# This recipe uses DC1 - A workgroup server 
#
# DC1 is initially a stand-alone workgroup server you convert
# into a DC with DNS. Assume you have installed PWSH 7 and VSCode using
# Scripts in Ch 1.

# 1. Install and load WindowsCompatability module then load 
#    the ServerManager module
Install-Module -Name WindowsCompatibility -Force
Import-Module -Name WindowsCompatibility
Import-WinModule ServerManager

# 2. Install the AD Domain Services feature and management tools
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools

# 3. Install the forest root DC
Import-WinModule -Name ADDSDeployment
$ADINSTALLHT = @{
  String      = 'Pa$$w0rd'
  AsPlainText = $True
  Force       = $True
}
$SECUREPW = ConvertTo-SecureString @ADINSTALLHT
$ADHT = @{
  DomainName                    = 'Reskit.Org' # Forest Root
  SafeModeAdministratorPassword = $SECUREPW
  InstallDNS                    = $True
  DomainMode                    = 'WinThreshold' # latest
  ForestMode                    = 'WinThreshold' # Latest
  Force                         = $True
  NoRebootOnCompletion          = $True
}
Install-ADDSForest @ADHT

# 4. Restart computer
Restart-Computer -Force

# 5. After reboot, log back into DC1 as Reskit\Administrator with the new
#    password.
Get-ADRootDSE |
  Format-Table -Property DNS*, *Functionality

# 6. Examine ADDS forest
Get-AdForest | 
  Format-Table -Property *master*, globaL*, Domains

# 7. View details of the domain
Get-ADDomain | 
  Format-Table -Property DNS*, PDC*, *master, Replica*

  