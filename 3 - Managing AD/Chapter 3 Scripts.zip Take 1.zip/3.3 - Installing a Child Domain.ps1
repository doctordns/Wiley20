# Chapter 3 - Topic 3 - Installing a Child Domain

# Run on UKDC1 - a workgroup computer
# DC1.Reskit.Org is the forest root DC
# Setup UKDC1 with PowerSHell/VS Code

# 1. Install and load WindowsCompatability module then load 
#    the ServerManager module
Install-Module -Name WindowsCompatibility -Force
Import-Module -Name WindowsCompatibility
Import-WinModule ServerManager

# 2. Check DC1 can be resolved, and 
#    can be reached over 445 and 389 from DC2
Resolve-DnsName -Name DC1.Reskit.Org -Type A
Test-NetConnection -ComputerName DC1.Reskit.Org -Port 445
Test-NetConnection -ComputerName DC1.Reskit.Org -Port 389

# 3. Add the AD DS features on UKDC1
$Features = 'AD-Domain-Services', 'DNS','RSAT-DHCP', 'Web-Mgmt-Tools'
Install-WindowsFeature -Name $Features -IncludeManagementTools

# 4. Create details of new domain uk.reskit.org
$PAS  = 'Pa$$w0rd'
$PSS  = ConvertTo-SecureString -String $Pas -AsPlainText -Force
Import-WinModule -Name ADDsDeployment
$URK  = "ADMINISTRATOR@reskit.org"
$PRK    = ConvertTo-SecureString 'Pa$$w0rd' -AsPlainText -Force
$Class  = 'System.Management.Automation.PSCredential'
$CredRK = New-Object -TypeName $Class -ArgumentList $URK,$PRK
$IHT =@{
   NewDomainName                 = 'UK'
   ParentDomainName              = 'Reskit.Org'
   DomainType                   = 'ChildDomain'
   SafeModeAdministratorPassword = $PSS
   ReplicationSourceDC           = "DC1.Reskit.Org"
   SiteName                      = 'Default-First-Site-Name'
   Force                         = $true
   Verbose                       = $true 
 } 

 # 5. Create UK.Reskit.Org and make this host ukdc1.uk.reskit.org
 Import-Winmodule -Name ADDsDeployment
 Install-ADDSDomain @IHT -Credential $Credrk  -whatif | 
   Out-Null


#  5. Now Promote DC2 to be a DC in the Reskit.Org domain by 
#     remoting to a 5.x endpoint
$URK = "administrator@reskit.org"
$PSS = ConvertTo-SecureString -String 'Pa$$w0rd' -AsPlainText -Force
$CredRK = New-Object system.management.automation.PSCredential $URK,$PSS
Invoke-Command -ComputerName DC2 -ScriptBlock $INSTALLSB -verbose -Authentication Credssp -Credential $CredRK|
  Out-Null

  
# 7 Reboot DC2
Restart-Computer -Force

### probably more.
