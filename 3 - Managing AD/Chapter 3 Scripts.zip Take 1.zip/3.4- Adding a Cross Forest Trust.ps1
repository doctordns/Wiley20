Using Namespace System.DirectoryServices
# 3.4 - Adding a cross Forest Trust

# Uses KapDC1 (a workgroup server with nothing else but powershell loaded)

# 1. Install and load WindowsCompatability module then load 
#    the ServerManager module on KAP DC1
Install-Module -Name WindowsCompatibility -Force
Import-Module -Name WindowsCompatibility
Import-WinModule ServerManager

# 2. Install the AD Domain Services feature and management tools
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools

# 3. Test Network Connectivity with DC1
Test-NetConnection -ComputerName DC1

# 4. Build Installation HT to install the forest root DC for Kapoho.Com
Import-WinModule -Name ADDSDeployment
$ADINSTALLHT = @{
  String      = 'Pa$$w0rd'
  AsPlainText = $True
  Force       = $True
}
$SECUREPW = ConvertTo-SecureString @ADINSTALLHT
$ADHT = @{
  DomainName                    = 'Kapoho.Com' # Forest Root
  SafeModeAdministratorPassword = $SECUREPW
  InstallDNS                    = $True
  DomainMode                    = 'WinThreshold' # latest
  ForestMode                    = 'WinThreshold' # Latest
  Force                         = $True
}
Install-ADDSForest @ADHT | Out-Null

# 5. Validate Kapoho.Com Forest
Get-ADForest

# 6. Adjust DNS on KAPDC1 to resolve Reskit.org from DC1
$CFHT = @{
   Name          = 'Reskit.Org'
   MasterServers = '10.10.10.10' 
   Passthru      = $True
}
Add-DnsServerConditionalForwarderZone @CFHT

# 7. Test this
Resolve-DNSName -Name DC1.Reskit.Org -Type A

# 8. Now setup a conditional forwarder on for Reskit.Org DNS
# Create script block 
$SB = {
  # Add CF zone
  $CFHT = @{
    Name          = 'Kapoho.Com'
    MasterServers = '10.10.10.131' 
   }
  Add-DnsServerConditionalForwarderZone @CFHT
  # Test it
  Resolve-DNSName -Name KAPDC1.Kapoho.Com
}  
# Create Credentials to run command on DC1
$URK   = 'Reskit\Administrator'
$PRK   = ConvertTo-SecureString 'Pa$$w0rd' -AsPlainText -Force
$CREDRK = New-Object System.Management.Automation.PSCredential $URK, $PRK
# Set WinRM
$PATH = 'WSMan:\localhost\Client\TrustedHosts'
Set-Item -Path $PATH -Value '*' -Force
# Run the script block
$NZHT = @{
  Computername = 'DC1.Reskit.Org'
  Script       = $SB
  Credential  = $CREDRK
}

# 9. Now invoke the script block
Invoke-Command @NZHT 

# 10. Get Reskit.Org and Kapoho.Com details
Using Namespace System.DirectoryServices
$Reskit       = 'Reskit.Org'
$User         = 'Administrator'
$UserPW       = 'Pa$$w0rd'
$Type         = 'ActiveDirectory.DirectoryContext'
$RKFHT = @{
  TypeName     = $Type
  ArgumentList = 'Forest',$Reskit,$User,$UserPW
}                
$RKF          = New-Object @RKFHT
$ReskitForest = [ActiveDirectory.Forest]::GetForest($RKF)
$KapohoForest = [ActiveDirectory.Forest]::GetCurrentForest()

# 11. View Reskit Forest Details 
$ReskitForest

# 12. View Kapoho Forest Details
$KapohoForest

# 13. Establish a trust
$KapohoForest.CreateTrustRelationship($ReskitForest,"Bidirectional")

 
# 14. Adjust ACL on DC1
$SB2 = {
# Ensure NTFSSecurity module is loaded on DC1
Install-Module -Name NTFSSecurity -Force -ErrorAction SilentlyContinue
# Create a file in C:\FOo
'XFT Test' | Out-File -FilePath 'C:\Foo\XFTTEST.Txt'
# Test ACL
Get-NTFSaccess -Path C:\Foo\XFTTEST.Txt | Format-Table
# Add Kapoho\Administrators into ACL for this file
$NTHT = @{
  Path         = 'C:\Foo\XFTTEST.TXT'
  Account      = 'Kapoho\Administrator'
  AccessRights = 'FullControl'
}
Add-NTFSAccess @NTHT
# Retest ACL
Get-NTFSaccess -Path C:\Foo\XFTTEST.Txt | Format-Table
}
$PHT = @{
  ComputerName = 'DC1.Reskit.Org'
  Credential   = $CREDRK
  ScriptBlock  = $SB2
}
Invoke-Command  @PHT
