# Recipe 3.7 - Implementing JEA
# Run on DC1


# Relies on AD IT, and JerryG user create earlier

# 1. Create transcripts folder
New-Item -Path C:\JEATranscripts -ItemType Directory

# 2. Build Role Module Folder
$PF      = $env:Programfiles
$CP      = 'WindowsPowerShell\Modules\RKDnsAdmins'
$ModPath = Join-Path -Path $PF -ChildPath $CP
New-Item -Path $ModPath -ItemType Directory | Out-Null

# 3. Create Role Capabilities file
$RCHT = @{
  Path            = 'C:\Foo\RKDnsAdmins.psrc' 
  Author          = 'Reskit Administration'
  CompanyName     = 'Reskit.Org' 
  Description     = 'Defines RKDnsAdmins role capabilities'
  AliasDefinition = @{name='gh';value='Get-Help'}
  ModulesToImport = 'Microsoft.PowerShell.Core','DnsServer'
  VisibleCmdlets  = ("Restart-Service",
                     @{ Name       = "Restart-Computer"; 
                        Parameters = @{Name = "ComputerName"}
                        ValidateSet = 'DC1, DC2'},
                      'DNSSERVER\*')
  VisibleExternalCommands = ('C:\Windows\System32\whoami.exe')
  VisibleFunctions = 'Get-HW'
  FunctionDefinitions = @{
    Name = 'Get-HW'
    Scriptblock = {'Hello JEA World'}}
}
New-PSRoleCapabilityFile @RCHT

# 4. Create the Module Manifest in the Module Folder
$P = Join-Path -Path $ModPath -ChildPath 'RKDnsAdmins.psd1'
New-ModuleManifest -Path $P -RootModule 'RKDNSAdmins.psm1'

# 5. Create a Role Capabilities Folder and Copy The PSRC
#    File Into the Module
$RCF = Join-Path -Path $ModPath -ChildPath 'RoleCapabilities'
New-Item -ItemType Directory $RCF
Copy-Item -Path $RCHT.Path -Destination $RCF -Force

# 6. Create a JEA Session Configuration file
$P = 'C:\Foo\RKDnsAdmins.pssc'
$RDHT = @{
  'Reskit\RKDnsAdmins' = @{RoleCapabilities = 'RKDnsAdmins'}
}
$PSCHT= @{
  Author              = 'DoctorDNS@Gmail.Com'
  Description         = 'Session Definition for RKDnsAdmins'
  SessionType         = 'RestrictedRemoteServer'   # ie JEA!
  Path                = $P                 # the output file
  RunAsVirtualAccount = $true
  TranscriptDirectory = 'C:\Foo\JeaTranscripts'
  RoleDefinitions     = $RDHT     # RKDnsAdmins role mapping
}
New-PSSessionConfigurationFile @PSCHT 

# 7. Test the session configuration file
Test-PSSessionConfigurationFile -Path C:\Foo\RKDnsAdmins.pssc 

# 8. Register the JEA Session Definition
$SCHT = @{
  Path  = 'C:\Foo\RKDnsAdmins.pssc'
  Name  = 'RKDnsAdmins' 
  Force =  $true 
}
Register-PSSessionConfiguration @SCHT

# 9. Check What the User Can Do
Get-PSSessionCapability -ConfigurationName RkDnsAdmins -Username 'Reskit\Jerryg' |
  Sort-Object Module

# 10. Create Credentials for user JerryG
$U    = 'JerryG@Reskit.Org'
$P    = ConvertTo-SecureString 'Pa$$w0rd' -AsPlainText -Force 
$Cred = New-Object System.Management.Automation.PSCredential $U,$P

# 11. Define Three Script Blocks and an Invocation Splatting Hast Table
$SB1   = {Get-Command}
$SB2   = {Get-HW}
$SB3   = {Get-Command -Name  '*-DNSSERVER*'}
$ICMHT = @{
  ComputerName      = 'DC1.Reskit.Org'
  Credential        = $Cred 
  ConfigurationName = 'RKDnsAdmins' 
} 

# 12. How many Commands are available within the JEA session
Invoke-Command -ScriptBlock $SB1 @ICMHT |
  Sort-Object -Property Module |
    Select-Object -First 15

# 13. Invoke a JEA Defined Function in a JEA Ssession As JerryG
Invoke-Command -ScriptBlock $SB2 @ICMHT

# 14. Get DNSServer commands available to JerryG
$C = Invoke-command -ScriptBlock $SB3 @ICMHT 
"$($C.Count) DNS commands available"

# 15 Examine the contents of the Transcripts folder:
Get-ChildItem -Path $PSCHT.TranscriptDirectory

# 16. Examine a transcript
Get-ChildItem -Path $PSCHT.TranscriptDirectory | 
  Select-Object -First 1  |
     Get-Content 



